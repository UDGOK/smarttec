z1Power - Sugarland BESS - Rev K - NATIVE ALTIUM DESIGNER FILES
PROPRIETARY - STR MEDICAL | FOR REVIEW ONLY - NOT FOR CONSTRUCTION

Z1-Sugarland.PrjPcb                 open this in Altium Designer - it lists
                                    BOTH schematic editions below
Z1-Sugarland.SchDoc                 ORIGINAL edition: every conductor drawn
                                    as a wire, byte-for-byte mirror of the
                                    verified KiCad ARCH E master routing
Z1-Sugarland-Simplified.SchDoc      SIMPLIFIED edition (recommended for
                                    review): hybrid net-label style produced
                                    by a 4-expert Altium panel review + a
                                    3-lens verification swarm + PE pass
Z1-Sugarland-SchDoc-preview.png     render of the original edition
Z1-Sugarland-Simplified-preview.png render of the simplified edition

Both are ARCH E (48x36in custom sheet) Protel/Altium binary schematics
(Schematic Capture Binary File v5.0 records in an OLE compound file).

WHAT "SIMPLIFIED" MEANS (panel consensus rules):
 - AC power train (480V, neutrals, 380Y/220V aux, 120V control) stays
   fully drawn - a PE reviewing power flow sees real copper.
 - Long cross-sheet signal runs (>=120 mm: ETH, CAN, FIRE, metering,
   24VDC distribution) are cut to short grid stubs joined by net labels,
   one label per wire fragment, anchor exactly on the wire at a point
   free of foreign crossings.
 - Power ports (one per pin): PE (ground symbol, down), DC_COM (bar,
   down), 24V_UPS / 24V_RMS / 24V_ETH (bar, up). Nothing else is a port -
   not 24V_BUS, not AC neutrals.
 - Dangling tails and tap whiskers pruned; junction dots regenerated
   only at genuine >=3-way tees; inherited half-grid jogs snapped to the
   5-unit grid; NoERC markers kept at IO1.8 and SW1.16 spare ports.

REAL COMPONENTS: every part carries Manufacturer / PartNumber /
Description parameters from the Rev K BOM (Properties panel; hidden on
canvas). Graphics reproduce the Carson/Battalion style.

VERIFICATION (no Altium install exists in the generating environment):
 - OLE container verified with olefile; frame-level binary audit of every
   record against the Protel format reference: 0 violations.
 - Parsed end-to-end by python-altium (independent third-party parser).
 - Connectivity rebuilt from the parsed files using Altium wiring rules
   (pin hotspots, wire endpoints, auto-junctions, junction-dot joins,
   geometrically-bound net labels and power ports) and diffed against the
   174-net golden design-intent table: 148/148 PASS on BOTH editions,
   bidirectional, with a 1:1 name-to-net bijection check.
 - Verifier itself mutation-tested: 8/8 seeded faults (dropped wire,
   renamed label, floating label, deleted port, stray junction, deleted
   NoERC, cross-net label, renamed port) all detected.
 - Visual render inspection at high zoom of every region; port symbol
   clearance and label spacing enforced at generation time.

KNOWN LIMITS: verified by parser + geometric extraction, not by opening
in Altium Designer itself. On first open, run Project >> Validate; the
project sets Net Identifier Scope = Flat. All engineering gating items in
the drawing notes still apply - PE review required before any release.
