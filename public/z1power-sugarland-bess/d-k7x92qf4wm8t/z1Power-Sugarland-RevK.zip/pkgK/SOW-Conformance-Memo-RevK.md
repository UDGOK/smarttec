# SOW / Verification-Doc Conformance Memo — Rev K (2026-08-09)
PROPRIETARY - STR MEDICAL | FOR REVIEW ONLY - PE REVIEW REQUIRED

Source documents held on file (sow/ + catl/ + repo root):
 1. Z1 Carson Indoor Enclosure drawing, 2 sheets (carson_indoor.pdf) - APPROVED CARSON BASELINE
 2. Z1 Carson PCS Enclosure drawing, 2 sheets (carson_pcs.pdf) - APPROVED CARSON BASELINE
 3. Z1Power Sugarland Engineering Scope of Work, 4 pp (sow/Z1-Sugarland-Engineering-SOW.pdf) - THE USE-CASE CHANGE
 4. Battalion/SmartTec Process & Verification Document PANEL-READY v2.0, Z1P-SUG-VER-001,
    2026-08-08, 9 pp (sow/Z1-Sugarland-Process-Verification-v2.0.pdf)
 5. Seven official CATL/Kehua documents (catl/): External Wiring Diagram + checklist,
    EnerOne+ Spec R08306P05L31, User Manual V5.0, MX34JAHL connector manual, cable SOP,
    Kehua PCS spec, Kehua PCS Modbus map.
Precedence applied in the design: SOW (use case) > official vendor docs (facts) >
v2.0 verification doc (prior fix set) > Carson drawings (reference wiring only).

CONFORMING (verified against the Rev K netlist/BOM): UC-2222A x2, QUINT CAP UPS,
NDR-75 pair + DRDN20, eGauge + PT + CPT, MBMU x3 + ETH x3, ARC-100 + CA-6075,
HT8AEHA + siren + 2x 12V FACP batteries, IOLogik, per-cabinet HVAC/BMS breakers,
480/380Y aux (now Kehua-integrated per Rev I), ERCOT deletions honored (no Siemens
relay, no CSIP, no SFP/fiber), single outdoor NEMA 4 enclosure, UL508A path,
swing-panel concept retained, Battalion EMS hardware architecture.

DELIBERATE, DOCUMENTED DEVIATIONS (already on the drawings):
 D1 Three switches -> one EDS-4014 with VLANs. CLIENT APPROVAL STILL PENDING.
 D2 USLKG5 signal terminals (SOW 4.2 'per Carson design') -> UK 5 N feed-through.
    Justification: Rev J critical finding - USLKG rail-bonds would ground both SLC
    legs, all releasing circuits, and CAN. USLKG kept ONLY at shield poles SB1-3.
 D3 CT shorting blocks (v2.0 fix #2, 6x UKK 5-TG) -> intentionally none.
    Justification: EGauge CTs are 333 mV VOLTAGE-output (UL 2808), open-circuit safe;
    v2.0's fix assumed current-output CTs. Independently upheld by the review board.
 D4 NDR-75 in the MBMU section (SOW 4.2) -> redundant NDR-240-24 pair + RM2 (Rev J/K).
 D5 Panel-mounted abort (Carson) -> supervised field abort + manual release stations
    at the cabinet line-up (NFPA 72 23.8.5.6, board R-14/R-15).

GAPS RAISED BY THIS CONFORMANCE PASS (new action items):
 G1 METERING - v2.0 fix #8 explicitly requires EG4130 with 18 CT inputs connected
    (PoI 3x2 + Solar 3x2 + BESS 3x2). Rev K carries EG4115 with 9 CTs. The 'single
    meter' deviation was tracked, but the EG4130/18-CT directive was not fully
    captured. DECISION NEEDED: client either approves the 9-CT/EG4115 deviation in
    writing, or M1 changes to EG4130 with 18 CTs (pin-compatible per v2.0; netlist
    change = 9 more CT channels, TB11 grows to 36 poles).
 G2 FACP THERMAL - v2.0 fix #4 commits to a Wakefield-Vette 124627 heat pipe +
    24 VDC 10 W fan above the FACP (verified 44.7C at 52.7C ambient). Rev K has the
    enclosure A/C + heat-balance sheet but does NOT carry the heat pipe. RECOMMEND:
    add heat pipe + fan as FACP spot cooling (cheap, passive, already validated) -
    one BOM line + one 24V fan branch; fold into the heat-balance sheet.
 G3 SOLAR PV CONTEXT - SOW lists 360 kW AC PV on site; the drawings meter it
    (CT_SOL) but no other PV interface is in panel scope. Confirm no PV control/
    rapid-shutdown interface is expected from this panel (responsibility matrix row).
 G4 SITE PLANNING - SOW section 7 requests estimated enclosure dimensions + weight.
    Rev K layout sheet (gate C4) must deliver this - still open.
 G5 v2.0 CAN note ('install 120R if needed, target ~60 ohm both ends') is CONSISTENT
    with the Rev K commissioning disposition for R1-R3 - no conflict; close as aligned.
