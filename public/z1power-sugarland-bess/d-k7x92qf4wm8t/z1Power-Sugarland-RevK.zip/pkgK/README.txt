z1Power - Sugarland BESS - REV K PACKAGE (2026-08-09)
PROPRIETARY - STR MEDICAL | FOR REVIEW ONLY - NOT FOR CONSTRUCTION - PE REVIEW REQUIRED

REV K = full remediation of the six-discipline PE-level review board's register
(see z1Power-Sugarland-PE-Review-Board-Register.pdf for the findings and
RevK-Disposition-Register.md for what was done about every one of them).

Highlights: hardwired fire->PCS trip (K1/X23), dedicated fire-alarm branch (CB9),
FSS Option B releasing architecture fully drawn (PSN-1000 + service disconnect +
EOLs + supervised field abort/manual-release; Option A removed - client decision),
Class A SLC re-drawn rack-to-rack, 24V restructured (PSU4/RM2 redundant BMS rail +
supply-health monitoring to the EMS), enclosure A/C + heater as real circuits off
the 380Y aux, every stale note purged with a build-time assertion so it cannot
recur, fuse/breaker/label/terminal/cable/24V/T2/NFPA-72/SCCR schedule package
(Z1SL-SCH-001), and two fabrication-gating vendor RFI letters.

Netlist grew 148 -> 174 nets. Verification: KiCad one-page 174/174, KiCad 9-sheet
174/174, Altium full 174/174, Altium simplified 174/174 (hardened extractor),
binary record audit 0 violations, cross-format comparator 0 divergences,
BOM<->netlist reconciler 0 failures.

one-page-ARCHE/    DWG Z1SL-E-001 REV K (ARCH E master) + PDF + golden netlist
multi-sheet-A3/    DWG Z1SL-A3-000 REV K, 9 sheets (new sheet 9: FSS releasing) + PDF
altium/            both native SchDoc editions + previews (Z1SL-ALT-001/-002)
schedules-rfis/    Z1SL-SCH-001 schedule workbook (9 tabs), RFI-001 Kehua, RFI-002 CATL/Potter
verification scripts included at root.
documents/         ALL documentation regenerated for Rev K (2026-08-09):
                   teaching docx, 20-page engineer handbook, wire-spec notes,
                   narrated video (3:46), live simulator, customer overview +
                   booklet (LTE + ring-wiring claims corrected per board D7).

STILL OPEN (cannot be closed by drawing): PE stamp; SCCR (utility fault current +
UL508A SB4); RFI-001/RFI-002 answers; NFPA72-W1 AHJ sign-off; heat-balance site
shading decision; Battalion VLAN; client deviations; wire numbers at fab release.
