"""Cross-format netlist comparator (board gate D6 / R-50).

Canonicalises the ARCH E one-page and the A3 multi-sheet KiCad netlists by
(refdes, pin NAME) - pin ordinals differ between the two symbol libraries -
and asserts the two extracted netlists are electrically identical, and that
each matches its own golden. Exit nonzero on any divergence."""
import sys
import xml.etree.ElementTree as ET


def load(path):
    root = ET.parse(path).getroot()
    # libpart pin num -> name
    pinname = {}
    for lp in root.find("libparts"):
        lib, part = lp.get("lib"), lp.get("part")
        pins = lp.find("pins")
        if pins is None:
            continue
        for p in pins:
            pinname[(lib, part, p.get("num"))] = p.get("name")
    comp_part = {}
    for c in root.find("components"):
        ls = c.find("libsource")
        comp_part[c.get("ref")] = (ls.get("lib"), ls.get("part"))
    nets = {}
    for n in root.find("nets"):
        members = set()
        for node in n:
            ref, pin = node.get("ref"), node.get("pin")
            lib, part = comp_part[ref]
            nm = pinname.get((lib, part, pin), pin)
            members.add((ref, nm))
        if len(members) >= 2:
            nets[n.get("name")] = frozenset(members)
    return nets


a = load("outG/netlist.xml")
b = load("outF/netlist.xml")


def canon(nets):
    return {ms for ms in nets.values()}


ca, cb = canon(a), canon(b)
fail = 0
for ms in sorted(ca - cb, key=sorted):
    print("FAIL net present only in ARCH E:", sorted(ms))
    fail += 1
for ms in sorted(cb - ca, key=sorted):
    print("FAIL net present only in A3 set:", sorted(ms))
    fail += 1

print("ARCH E nets: %d   A3 nets: %d   divergences: %d"
      % (len(ca), len(cb), fail))
if fail:
    print("RESULT: FAIL")
    sys.exit(1)
print("RESULT: PASS - both drawing formats are electrically identical "
      "(canonicalised by pin name)")
