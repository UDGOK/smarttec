#!/usr/bin/env python3
"""Adversarial binary record-structure audit of Z1-Sugarland-Simplified.SchDoc."""
import sys, json, struct, olefile

PATH = '/home/claude/z1-sugarland/outA/Z1-Sugarland-Simplified.SchDoc'
GOLD = '/home/claude/z1-sugarland/outG/golden_nets.json'

golden = json.load(open(GOLD))
golden_names = set(golden.keys())
RAILS = {'PE','DC_COM','24V_UPS','24V_RMS','24V_ETH'}
rail_pin_counts = {r: len(golden[r]) for r in RAILS}

viol = []
def V(msg): viol.append(msg)

# ---------- OLE container ----------
ole = olefile.OleFileIO(PATH)
streams = ole.listdir()
print("STREAMS:", streams)
meta_ok = True
for s in (['FileHeader'], ['Storage']):
    if s not in streams:
        V(f"OLE: missing stream {s}")
# sector sanity: try reading every stream fully
for s in streams:
    try:
        data = ole.openstream(s).read()
        print(f"stream {s}: {len(data)} bytes")
    except Exception as e:
        V(f"OLE: stream {s} unreadable: {e}")

fh = ole.openstream('FileHeader').read()
storage = ole.openstream('Storage').read() if ['Storage'] in streams else None

# ---------- frame walker ----------
def walk(buf, streamname):
    recs = []
    off = 0
    n = len(buf)
    idx = 0
    while off < n:
        if off + 4 > n:
            V(f"{streamname}: trailing garbage, {n-off} bytes at offset {off}: {buf[off:off+16]!r}")
            break
        length = struct.unpack_from('<H', buf, off)[0]
        b2, b3 = buf[off+2], buf[off+3]
        payload = buf[off+4:off+4+length]
        if len(payload) != length:
            V(f"{streamname} frame {idx} @off {off}: declared len {length} but only {len(payload)} bytes remain")
            break
        if b2 != 0:
            V(f"{streamname} frame {idx} @off {off}: byte2 = {b2:#x}, expected 0x00")
        if b3 != 0:
            V(f"{streamname} frame {idx} @off {off}: record type byte = {b3:#x}, expected 0x00 (property list)")
        # final NUL
        if length == 0 or payload[-1:] != b'\x00':
            V(f"{streamname} frame {idx} @off {off}: payload does not end with NUL: ...{payload[-8:]!r}")
            body = payload
        else:
            body = payload[:-1]
        if b'\x00' in body:
            V(f"{streamname} frame {idx} @off {off}: embedded NUL inside payload body")
        try:
            text = body.decode('windows-1252')
        except UnicodeDecodeError as e:
            V(f"{streamname} frame {idx} @off {off}: not windows-1252 decodable: {e}")
            text = body.decode('windows-1252', 'replace')
        recs.append((idx, off, text, payload))
        off += 4 + length
        idx += 1
    return recs

def props(text):
    """Parse |A=B property list into dict; flag empties/dupes/no-pipe issues."""
    d = {}
    issues = []
    if not text.startswith('|'):
        issues.append(f"does not start with '|': {text[:40]!r}")
        parts = text.split('|')
    else:
        parts = text[1:].split('|')
    for p in parts:
        if not p:
            issues.append("empty property (double pipe or trailing pipe)")
            continue
        if '=' not in p:
            issues.append(f"property without '=': {p!r}")
            continue
        k, _, v = p.partition('=')
        k = k.upper()
        if k in d and d[k] != v:
            issues.append(f"duplicate key {k} with differing values {d[k]!r} vs {v!r}")
        d[k] = v
    return d, issues

recs = walk(fh, 'FileHeader')
print(f"FileHeader: {len(recs)} frames")

# ---------- header record ----------
h_idx, h_off, h_text, _ = recs[0]
hp, hiss = props(h_text)
for i in hiss: V(f"FileHeader header record: {i}")
if 'HEADER' not in hp or not hp['HEADER'].startswith('Protel for Windows - Schematic Capture Binary File Version 5.0'):
    V(f"header HEADER wrong: {hp.get('HEADER')!r}")
weight = int(hp.get('WEIGHT', '-1'))
nobj = len(recs) - 1
if weight != nobj:
    V(f"header WEIGHT={weight} but object count (frames after header) = {nobj}")

# ---------- per-record checks ----------
objs = []  # index-from-0 objects
for i, (fi, off, text, payload) in enumerate(recs[1:]):
    d, iss = props(text)
    for m in iss:
        V(f"obj {i} (RECORD={d.get('RECORD')}): {m} | payload[:80]={text[:80]!r}")
    objs.append((i, off, d, text))

def excerpt(t, n=110): return t[:n] + ('...' if len(t) > n else '')

# record 0 sheet
i0, _, d0, t0 = objs[0]
if d0.get('RECORD') != '31':
    V(f"obj 0 is RECORD={d0.get('RECORD')}, expected 31 (Sheet): {excerpt(t0)}")
else:
    try: fic = int(d0.get('FONTIDCOUNT', '0'))
    except ValueError: fic = -1; V(f"obj 0: FONTIDCOUNT not integer: {d0.get('FONTIDCOUNT')!r}")
    for n in range(1, fic+1):
        if f'FONTNAME{n}' not in d0: V(f"obj 0 Sheet: FONTIDCOUNT={fic} but FONTNAME{n} missing")
        if f'SIZE{n}' not in d0: V(f"obj 0 Sheet: FONTIDCOUNT={fic} but SIZE{n} missing")
    # extra fonts beyond count
    n = fic + 1
    while f'FONTNAME{n}' in d0 or f'SIZE{n}' in d0:
        V(f"obj 0 Sheet: FONTNAME{n}/SIZE{n} present beyond FONTIDCOUNT={fic}")
        n += 1

# component indices
comp_idx = {i for i,_,d,_ in objs if d.get('RECORD') == '1'}
rec_counts = {}
uids = {}
pp_counts = {}
noerc = []
netlabels = 0

def on_grid(v, grid=5):
    try: return int(v) % grid == 0
    except (ValueError, TypeError): return False

for i, off, d, t in objs:
    r = d.get('RECORD')
    rec_counts[r] = rec_counts.get(r, 0) + 1
    uid = d.get('UNIQUEID')
    if uid is not None:
        if uid in uids:
            V(f"obj {i}: duplicate UNIQUEID {uid!r} (also obj {uids[uid]}) | {excerpt(t)}")
        else:
            uids[uid] = i
    # OWNERINDEX must point to a component for child records
    if 'OWNERINDEX' in d and r not in ('16','44','45','46','47','48','32','33'):
        try: oi = int(d['OWNERINDEX'])
        except ValueError: oi = None; V(f"obj {i} RECORD={r}: OWNERINDEX not int: {d['OWNERINDEX']!r}")
        if oi is not None and oi not in comp_idx:
            V(f"obj {i} RECORD={r}: OWNERINDEX={oi} does not point to a RECORD=1 component | {excerpt(t)}")
    if r == '17':
        txt = d.get('TEXT')
        style = d.get('STYLE'); ori = d.get('ORIENTATION', '0')
        if txt not in RAILS:
            V(f"obj {i} RECORD=17: TEXT={txt!r} not in allowed rails | {excerpt(t)}")
        pp_counts[txt] = pp_counts.get(txt, 0) + 1
        if style not in ('2','4'):
            V(f"obj {i} RECORD=17 TEXT={txt}: STYLE={style!r} not in {{2,4}} | {excerpt(t)}")
        if ori not in ('1','3'):
            V(f"obj {i} RECORD=17 TEXT={txt}: ORIENTATION={ori!r} not in {{1,3}} | {excerpt(t)}")
        if txt == 'PE' and (style, ori) != ('4','3'):
            V(f"obj {i} RECORD=17 PE: STYLE/ORIENTATION=({style},{ori}), spec says (4,3) | {excerpt(t)}")
        if txt == 'DC_COM' and (style, ori) != ('2','3'):
            V(f"obj {i} RECORD=17 DC_COM: STYLE/ORIENTATION=({style},{ori}), spec says (2,3) | {excerpt(t)}")
        if txt in ('24V_UPS','24V_RMS','24V_ETH') and (style, ori) != ('2','1'):
            V(f"obj {i} RECORD=17 {txt}: STYLE/ORIENTATION=({style},{ori}), spec says (2,1) | {excerpt(t)}")
        if d.get('SHOWNETNAME') != 'T':
            V(f"obj {i} RECORD=17 TEXT={txt}: SHOWNETNAME={d.get('SHOWNETNAME')!r}, expected T | {excerpt(t)}")
    elif r == '25':
        netlabels += 1
        txt = d.get('TEXT')
        if txt not in golden_names:
            V(f"obj {i} RECORD=25: TEXT={txt!r} is not a golden net name | {excerpt(t)}")
        for c in ('LOCATION.X','LOCATION.Y'):
            if not on_grid(d.get(c)):
                V(f"obj {i} RECORD=25 TEXT={txt}: {c}={d.get(c)!r} not on 5-unit grid | {excerpt(t)}")
    elif r == '2':
        try: pc = int(d.get('PINCONGLOMERATE','0'))
        except ValueError: pc = -1; V(f"obj {i} RECORD=2: PINCONGLOMERATE not int: {d.get('PINCONGLOMERATE')!r}")
        if pc >= 0 and (pc & 0x03) not in (0, 2):
            V(f"obj {i} RECORD=2 pin {d.get('DESIGNATOR')}: PINCONGLOMERATE={pc} orientation bits={pc&3}, not in {{0,2}} | {excerpt(t)}")
        try: pl = int(d.get('PINLENGTH','0'))
        except ValueError: pl = -1
        if pl <= 0:
            V(f"obj {i} RECORD=2 pin {d.get('DESIGNATOR')}: PINLENGTH={d.get('PINLENGTH')!r} not > 0 | {excerpt(t)}")
        for c in ('LOCATION.X','LOCATION.Y'):
            if not on_grid(d.get(c)):
                V(f"obj {i} RECORD=2 pin {d.get('DESIGNATOR')}: {c}={d.get(c)!r} not on 5-unit grid | {excerpt(t)}")
        if 'OWNERINDEX' not in d:
            V(f"obj {i} RECORD=2: missing OWNERINDEX | {excerpt(t)}")
    elif r == '22':
        noerc.append((i, d.get('LOCATION.X'), d.get('LOCATION.Y')))

# power port counts vs golden pin counts
for rail in RAILS:
    want = rail_pin_counts[rail]
    got = pp_counts.get(rail, 0)
    if got != want:
        V(f"RECORD=17 count for {rail}: {got}, expected {want} (golden pin count)")
for txt, c in pp_counts.items():
    if txt not in RAILS:
        V(f"RECORD=17 rail {txt!r}: {c} ports exist but rail not allowed")

print("record type counts:", dict(sorted(rec_counts.items(), key=lambda kv: int(kv[0]) if kv[0] and kv[0].isdigit() else 999)))
print(f"net labels: {netlabels}, NoERC markers: {len(noerc)} at {noerc}")

# ---------- Storage stream ----------
if storage is not None:
    srecs = walk(storage, 'Storage')
    if len(srecs) != 1:
        V(f"Storage: {len(srecs)} frames, expected exactly 1 (degenerate header)")
    if srecs:
        st = srecs[0][2]
        if st != '|HEADER=Icon storage|WEIGHT=0':
            V(f"Storage header text = {st!r}, expected '|HEADER=Icon storage|WEIGHT=0'")

# ---------- PrjPcb ----------
prj = open('/home/claude/z1-sugarland/outA/Z1-Sugarland.PrjPcb', encoding='utf-8', errors='replace').read()
for doc in ('Z1-Sugarland.SchDoc', 'Z1-Sugarland-Simplified.SchDoc'):
    if doc not in prj:
        V(f"PrjPcb: does not reference {doc}")

print("\n==== VIOLATIONS:", len(viol), "====")
for v in viol:
    print("VIOLATION:", v)
