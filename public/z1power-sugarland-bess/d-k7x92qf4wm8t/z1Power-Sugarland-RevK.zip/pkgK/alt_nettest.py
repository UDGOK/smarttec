"""Independent netlist extraction from the generated .SchDoc.

Parses outA/Z1-Sugarland.SchDoc with python-altium (third-party parser,
not our writer), rebuilds connectivity using Altium's rules:
  - pin connection point = LOCATION + PINLENGTH in rotation direction
  - wires connect at shared endpoints
  - a wire endpoint or pin landing on the interior of another wire connects
  - net labels bind their name to the wire at their LOCATION
Then diffs the resulting {net: {(ref, pin)}} against the golden
design-intent table (same file the KiCad test uses). Exit nonzero on any
mismatch.
"""
import json
import sys
sys.path.insert(0, "/home/claude/python-altium")
import altium

sheet, _, _ = altium.read("outA/Z1-Sugarland.SchDoc")

pins = []          # (ref, pindesig, (x, y))
wires = []         # [(x1,y1),(x2,y2)]
netlabels = []     # (name, (x, y))
junctions = []     # (x, y)

DIRS = {0: (1, 0), 1: (0, 1), 2: (-1, 0), 3: (0, -1)}

for comp in sheet.children:
    p = comp.properties
    r = p.get_int("RECORD")
    if r == altium.Record.COMPONENT:
        ref = None
        comppins = []
        for ch in comp.children:
            cp = ch.properties
            cr = cp.get_int("RECORD")
            if cr == altium.Record.DESIGNATOR:
                ref = cp["TEXT"].decode()
            elif cr == altium.Record.PIN:
                x = cp.get_int("LOCATION.X")
                y = cp.get_int("LOCATION.Y")
                ln = cp.get_int("PINLENGTH")
                dx, dy = DIRS[cp.get_int("PINCONGLOMERATE") & 3]
                comppins.append((cp["DESIGNATOR"].decode(),
                                 (x + dx * ln, y + dy * ln)))
        assert ref, "component without designator"
        for d, pt in comppins:
            pins.append((ref, d, pt))
    elif r == altium.Record.WIRE:
        n = p.get_int("LOCATIONCOUNT")
        pts = [(p.get_int("X%d" % i), p.get_int("Y%d" % i))
               for i in range(1, n + 1)]
        for a, b in zip(pts, pts[1:]):
            wires.append((a, b))
    elif r == altium.Record.NET_LABEL:
        netlabels.append((p["TEXT"].decode(),
                          (p.get_int("LOCATION.X"), p.get_int("LOCATION.Y"))))
    elif r == altium.Record.JUNCTION:
        junctions.append((p.get_int("LOCATION.X"), p.get_int("LOCATION.Y")))

# ---------------- union-find ----------------
parent = {}


def find(a):
    while parent.setdefault(a, a) != a:
        parent[a] = parent[parent[a]]
        a = parent[a]
    return a


def union(a, b):
    ra, rb = find(a), find(b)
    if ra != rb:
        parent[ra] = rb


def on_seg(pt, seg):
    (x, y), ((x1, y1), (x2, y2)) = pt, seg
    if x1 == x2:
        return x == x1 and min(y1, y2) <= y <= max(y1, y2)
    if y1 == y2:
        return y == y1 and min(x1, x2) <= x <= max(x1, x2)
    return False


# wire self nodes
for i, (a, b) in enumerate(wires):
    union(("w", i), a)
    union(("w", i), b)
# endpoint-on-interior of another wire (Altium auto-junction)
for i, (a, b) in enumerate(wires):
    for e in (a, b):
        for j, seg in enumerate(wires):
            if i != j and on_seg(e, seg):
                union(e, ("w", j))
# pins
for ref, d, pt in pins:
    union(("p", ref, d), pt)
    for j, seg in enumerate(wires):
        if on_seg(pt, seg):
            union(pt, ("w", j))
# manual junctions unify anything at that exact point (they sit on wires)
for pt in junctions:
    for j, seg in enumerate(wires):
        if on_seg(pt, seg):
            union(pt, ("w", j))
# labels
names = {}
for name, pt in netlabels:
    attached = False
    for j, seg in enumerate(wires):
        if on_seg(pt, seg):
            union(pt, ("w", j))
            attached = True
    if not attached:
        print("WARN net label %r not on any wire at %s" % (name, (pt,)))
    names.setdefault(find(pt), set()).add(name)

# collapse: group -> members / names
groups = {}
for ref, d, pt in pins:
    groups.setdefault(find(("p", ref, d)), set()).add((ref, d))
gnames = {}
for root, ns in list(names.items()):
    gnames.setdefault(find(root), set()).update(ns)

# name conflicts (two different labels on one electrical net)?
conflicts = {r: ns for r, ns in gnames.items() if len(ns) > 1}

# ---------------- golden diff ----------------
golden = {k: set(map(tuple, v)) for k, v in
          json.load(open("outG/golden_nets.json")).items()}

member_to_group = {}
for root, members in groups.items():
    for m in members:
        member_to_group[m] = root

fail = 0
matched = 0
for gname, gmembers in sorted(golden.items()):
    anchor = next(iter(gmembers))
    root = member_to_group.get(anchor)
    if root is None:
        print("FAIL %s: %s not connected to anything" % (gname, anchor))
        fail += 1
        continue
    amembers = groups[root]
    if amembers != gmembers:
        print("FAIL %s:" % gname)
        print("   missing in altium: %s" % sorted(gmembers - amembers))
        print("   extra in altium:   %s" % sorted(amembers - gmembers))
        fail += 1
        continue
    labs = gnames.get(root, set())
    if labs and gname not in labs:
        print("FAIL %s: labelled %s instead" % (gname, sorted(labs)))
        fail += 1
        continue
    matched += 1

for root, ns in conflicts.items():
    print("FAIL label conflict on one net: %s" % sorted(ns))
    fail += 1

# any multi-pin altium group not in golden?
gsets = {frozenset(v) for v in golden.values()}
orphan = [sorted(m) for m in groups.values()
          if len(m) >= 2 and frozenset(m) not in gsets]
for o in orphan:
    print("FAIL unexpected altium net: %s" % o)
    fail += len(orphan)

print()
print("altium pins: %d   wires: %d   labels: %d   junction dots: %d"
      % (len(pins), len(wires), len(netlabels), len(junctions)))
print("matched: %d/%d   failures: %d" % (matched, len(golden), fail))
if fail:
    print("RESULT: FAIL")
    sys.exit(1)
print("RESULT: PASS - Altium-parsed geometry reproduces the verified "
      "current design intent (%d nets)" % len(golden))
