"""Hardened independent netlist extraction for the SIMPLIFIED .SchDoc.

Panel-mandated verification order (altium_panel_recs.json):
  1. GEOMETRY FIRST - union-find over wire endpoints, endpoint-on-interior
     auto-junctions, and pin hotspots (LOCATION + PINLENGTH along
     PINCONGLOMERATE direction). No names involved yet.
  2. BIND identifiers geometrically - every net label (RECORD=25) and
     power port (RECORD=17) must have its LOCATION on a wire of some
     group. A floating label or port is a HARD FAIL, not a warning.
  3. MERGE BY NAME - only geometrically-bound identifiers merge groups.
     Labels and power ports share one namespace.
  4. DIFF - bidirectional membership diff against all 148 golden nets,
     plus a bijection check: exactly 148 named groups, names exactly
     equal to the golden key set, each mapping to exactly one group.
  5. LINTS - case-insensitive name collisions, junction validity
     (every junction dot sits on a wire with electrical degree >= 3),
     NoERC singleton assertions (IO1.8, SW1.16), hidden-pin check,
     accidental-short diagnostic (any group holding pins of 2+ golden
     nets is reported with both names).

Usage: python3 alt_nettest_simple.py [SchDoc path]
Exit nonzero on any FAIL.
"""
import json
import sys

sys.path.insert(0, "/home/claude/python-altium")
import altium

PATH = sys.argv[1] if len(sys.argv) > 1 else \
    "outA/Z1-Sugarland-Simplified.SchDoc"
sheet, _, _ = altium.read(PATH)

pins = []          # (ref, pindesig, (x, y))
hidden_pins = []
wires = []         # ((x1,y1),(x2,y2))
netlabels = []     # (name, (x, y))
powerports = []    # (name, (x, y), style)
junctions = []     # (x, y)
noercs = []        # (x, y)

DIRS = {0: (1, 0), 1: (0, 1), 2: (-1, 0), 3: (0, -1)}

for comp in sheet.children:
    p = comp.properties
    r = p.get_int("RECORD")
    if r == altium.Record.COMPONENT:
        ref = None
        comppins = []
        for ch in comp.children:
            cp = ch.properties
            cr = cp.get_int("RECORD")
            if cr == altium.Record.DESIGNATOR:
                ref = cp["TEXT"].decode()
            elif cr == altium.Record.PIN:
                if cp.get_bool("ISHIDDEN"):
                    hidden_pins.append((ref, cp["DESIGNATOR"].decode()))
                x = cp.get_int("LOCATION.X")
                y = cp.get_int("LOCATION.Y")
                ln = cp.get_int("PINLENGTH")
                dx, dy = DIRS[cp.get_int("PINCONGLOMERATE") & 3]
                comppins.append((cp["DESIGNATOR"].decode(),
                                 (x + dx * ln, y + dy * ln)))
        assert ref, "component without designator"
        for d, pt in comppins:
            pins.append((ref, d, pt))
    elif r == altium.Record.WIRE:
        n = p.get_int("LOCATIONCOUNT")
        pts = [(p.get_int("X%d" % i), p.get_int("Y%d" % i))
               for i in range(1, n + 1)]
        for a, b in zip(pts, pts[1:]):
            wires.append((a, b))
    elif r == altium.Record.NET_LABEL:
        netlabels.append((p["TEXT"].decode(),
                          (p.get_int("LOCATION.X"),
                           p.get_int("LOCATION.Y"))))
    elif r == altium.Record.POWER_PORT:
        powerports.append((p["TEXT"].decode(),
                           (p.get_int("LOCATION.X"),
                            p.get_int("LOCATION.Y")),
                           p.get_int("STYLE"),
                           p.get_int("ORIENTATION"),
                           p.get_bool("SHOWNETNAME"),
                           p["TEXT"]))
    elif r == altium.Record.JUNCTION:
        junctions.append((p.get_int("LOCATION.X"),
                          p.get_int("LOCATION.Y")))
    elif r == altium.Record.NO_ERC:
        noercs.append((p.get_int("LOCATION.X"),
                       p.get_int("LOCATION.Y")))

fail = 0


def FAIL(msg):
    global fail
    print("FAIL " + msg)
    fail += 1


# ---------------- step 1: pure geometry ----------------
parent = {}


def find(a):
    while parent.setdefault(a, a) != a:
        parent[a] = parent[parent[a]]
        a = parent[a]
    return a


def union(a, b):
    ra, rb = find(a), find(b)
    if ra != rb:
        parent[ra] = rb


def on_seg(pt, seg):
    (x, y), ((x1, y1), (x2, y2)) = pt, seg
    if x1 == x2:
        return x == x1 and min(y1, y2) <= y <= max(y1, y2)
    if y1 == y2:
        return y == y1 and min(x1, x2) <= x <= max(x1, x2)
    return False


for i, (a, b) in enumerate(wires):
    union(("w", i), a)
    union(("w", i), b)
for i, (a, b) in enumerate(wires):
    for e in (a, b):
        for j, seg in enumerate(wires):
            if i != j and on_seg(e, seg):
                union(e, ("w", j))
for ref, d, pt in pins:
    union(("p", ref, d), pt)
    for j, seg in enumerate(wires):
        if on_seg(pt, seg):
            union(pt, ("w", j))
# junction dots CONNECT everything passing through them (Altium
# semantics): a dot placed on a crossing joins the crossing wires.
# Modelling this is what turns a stray dot into a detectable short
# (mutation-audit finding F1).
for jp in junctions:
    for j, seg in enumerate(wires):
        if on_seg(jp, seg):
            union(jp, ("w", j))
    for ref, d, pt in pins:
        if pt == jp:
            union(jp, ("p", ref, d))

# ---------------- step 2: geometric binding of identifiers ----------------
idents = []        # (kind, name, group_root)
for name, pt in netlabels:
    hits = [j for j, seg in enumerate(wires) if on_seg(pt, seg)]
    if not hits:
        FAIL("floating net label %r at %s (binds nothing)" % (name, (pt,)))
        continue
    for j in hits:
        union(pt, ("w", j))
    idents.append(("label", name, pt))
for name, pt, style, ori, shownn, raw in powerports:
    hits = [j for j, seg in enumerate(wires) if on_seg(pt, seg)]
    onpin = [(ref, d) for ref, d, ppt in pins if ppt == pt]
    if not hits and not onpin:
        FAIL("floating power port %r at %s (binds nothing)" % (name, (pt,)))
        continue
    for j in hits:
        union(pt, ("w", j))
    idents.append(("port", name, pt))

# power-port attribute rules (mutation-audit finding F2): ports are
# allowed for exactly five rails, with mandated STYLE/ORIENTATION,
# SHOWNETNAME=T, byte-identical TEXT, and one port per golden pin.
PORT_SPEC = {          # net -> (STYLE, allowed ORIENTATIONs)
    b"PE":      (4, {1, 3}),
    b"DC_COM":  (2, {1, 3}),
    b"24V_UPS": (2, {1, 3}),
    b"24V_RMS": (2, {1, 3}),
    b"24V_ETH": (2, {1, 3}),
}
PREFERRED_ORI = {b"PE": 3, b"DC_COM": 3,
                 b"24V_UPS": 1, b"24V_RMS": 1, b"24V_ETH": 1}
port_count = {}
for name, pt, style, ori, shownn, raw in powerports:
    spec = PORT_SPEC.get(raw)
    if spec is None:
        FAIL("power port for non-rail net %r (forbidden)" % name)
        continue
    if style != spec[0]:
        FAIL("power port %s at %s: STYLE=%d, expected %d"
             % (name, (pt,), style, spec[0]))
    if ori not in spec[1]:
        FAIL("power port %s at %s: ORIENTATION=%d invalid"
             % (name, (pt,), ori))
    if not shownn:
        FAIL("power port %s at %s: SHOWNETNAME not set" % (name, (pt,)))
    if pt[0] % 5 or pt[1] % 5:
        FAIL("power port %s at %s: off the 5-unit grid" % (name, (pt,)))
    port_count[name] = port_count.get(name, 0) + 1

# ---------------- step 3: merge by name (bound identifiers only) ---------
by_name = {}
for kind, name, pt in idents:
    by_name.setdefault(name, []).append(find(pt))
for name, roots in by_name.items():
    for r in roots[1:]:
        union(roots[0], r)

# ---------------- collapse groups ----------------
groups = {}
for ref, d, pt in pins:
    groups.setdefault(find(("p", ref, d)), set()).add((ref, d))
gnames = {}
for kind, name, pt in idents:
    gnames.setdefault(find(pt), set()).add(name)

# multiple distinct names on one electrical group = conflict
for root, ns in gnames.items():
    if len(ns) > 1:
        FAIL("name conflict on one net: %s" % sorted(ns))

# ---------------- step 4: golden diff + bijection ----------------
golden = {k: set(map(tuple, v)) for k, v in
          json.load(open("outG/golden_nets.json")).items()}

# case-insensitive collision lint (golden + drawing identifiers)
seen = {}
for name in set(list(golden) + [n for _k, n, _p in idents]):
    other = seen.setdefault(name.lower(), name)
    if other != name:
        FAIL("case-insensitive name collision: %r vs %r" % (name, other))

member_to_group = {}
for root, members in groups.items():
    for m in members:
        member_to_group[m] = root

matched = 0
name_to_group = {}
for gname, gmembers in sorted(golden.items()):
    anchor = next(iter(gmembers))
    root = member_to_group.get(anchor)
    if root is None:
        FAIL("%s: %s not connected to anything" % (gname, anchor))
        continue
    amembers = groups[root]
    ok = True
    if amembers != gmembers:
        FAIL("%s:\n   missing in altium: %s\n   extra in altium:   %s"
             % (gname, sorted(gmembers - amembers),
                sorted(amembers - gmembers)))
        ok = False
    labs = gnames.get(root, set())
    if not labs:
        FAIL("%s: net carries NO label or power port" % gname)
        ok = False
    elif labs != {gname}:
        FAIL("%s: identified as %s instead" % (gname, sorted(labs)))
        ok = False
    if ok:
        matched += 1
        name_to_group[gname] = root

# bijection: named groups exactly = golden keys, one group per name
named_groups = {}
for root, ns in gnames.items():
    for n in ns:
        named_groups.setdefault(n, set()).add(root)
for n, roots in sorted(named_groups.items()):
    if n not in golden:
        FAIL("identifier %r names no golden net" % n)
    if len(roots) > 1:
        FAIL("identifier %r spans %d disconnected groups that never "
             "merged" % (n, len(roots)))
if len(set(named_groups) & set(golden)) != len(golden):
    missing = sorted(set(golden) - set(named_groups))
    if missing:
        FAIL("golden nets with no identifier in drawing: %s" % missing)

# distinct golden nets must remain distinct groups (short guard)
rev = {}
for gname, root in name_to_group.items():
    if root in rev:
        FAIL("SHORT: golden nets %r and %r are one electrical group"
             % (rev[root], gname))
    rev[root] = gname

# unnamed multi-pin groups
gsets = {frozenset(v) for v in golden.values()}
for root, members in groups.items():
    if len(members) >= 2 and frozenset(members) not in gsets:
        FAIL("unexpected altium net (not in golden): %s" % sorted(members))

# ---------------- step 5: structural lints ----------------
if hidden_pins:
    FAIL("hidden pins present: %s" % hidden_pins[:8])

# port count per rail == golden pin count (one port per pin)
for raw, _spec in PORT_SPEC.items():
    name = raw.decode()
    want = len(golden.get(name, ()))
    got = port_count.get(name, 0)
    if got != want:
        FAIL("rail %s: %d ports for %d pins (must be 1:1)"
             % (name, got, want))

# junction validity, both directions (mutation-audit finding F3):
# every dot sits on a >= 3-way point, AND every >= 3-way point has a dot.
def degree(p):
    deg = 0
    for a, b in wires:
        if p == a or p == b:
            deg += 1
        elif on_seg(p, (a, b)):
            deg += 2
    for _r, _d, pt in pins:
        if pt == p:
            deg += 1
    return deg


jset = set(junctions)
for jp in junctions:
    if degree(jp) < 3:
        FAIL("junction dot at %s has degree %d (< 3)" % ((jp,), degree(jp)))
tee_pts = set()
for a, b in wires:
    tee_pts.add(a)
    tee_pts.add(b)
for _r, _d, pt in pins:
    tee_pts.add(pt)
for p in tee_pts:
    if p not in jset and degree(p) >= 3:
        FAIL("3-way point at %s has NO junction dot" % (p,))

# NoERC singletons (dynamic, REV K): every pin that belongs to NO golden
# net is an intentional no-connect - it must be electrically alone and
# carry a NoERC marker; and there must be no extra markers.
golden_members = {m for v in golden.values() for m in v}
nc_pins = [(ref, d, pt) for ref, d, pt in pins
           if (ref, d) not in golden_members]
for ref, d, pt in nc_pins:
    root = member_to_group.get((ref, d))
    if root is not None and groups[root] != {(ref, d)}:
        FAIL("NoERC pin %s.%s is connected to %s" %
             (ref, d, sorted(groups[root] - {(ref, d)})))
    if pt not in noercs:
        FAIL("NoERC pin %s.%s has no NoERC marker at %s" % (ref, d, (pt,)))
if len(noercs) != len(nc_pins):
    FAIL("expected %d NoERC markers (one per unassigned pin), found %d"
         % (len(nc_pins), len(noercs)))

print()
print("altium pins: %d   wires: %d   labels: %d   power ports: %d   "
      "junctions: %d   noerc: %d"
      % (len(pins), len(wires), len(netlabels), len(powerports),
         len(junctions), len(noercs)))
print("matched: %d/%d   failures: %d" % (matched, len(golden), fail))
if fail:
    print("RESULT: FAIL")
    sys.exit(1)
print("RESULT: PASS - simplified SchDoc reproduces all %d golden nets "
      "with geometric binding, bijective naming, and clean lints"
      % len(golden))
