"""BOM <-> netlist bidirectional reconciler (board gate D6 / R-60).

Every refdes in the netlist must appear on exactly one BOM line (or in a
documented CATL/field-supplied line), and every refdes-bearing BOM line must
point at netlist components. Purchased items with no refdes are allowed only
for bulk/consumable categories. Exit nonzero on any orphan."""
import json, re, sys

import bomH  # SECTIONS

golden = json.load(open("outG/golden_nets.json"))
net_refs = {r for v in golden.values() for (r, _p) in v}
# components that exist but may have no net entries never happens (all pinned)

BULK_OK = re.compile(
    r"patch cords|holder|wire:|DIN rail|label|enclosure|conduit|bus bar|"
    r"crimp|plug|adapter|pad|bond kit", re.I)

def expand(tok):
    tok = tok.strip()
    m = re.match(r"^([A-Za-z]+)(\d+)-(?:[A-Za-z]*)(\d+)$", tok)
    if m:
        p, a, b = m.group(1), int(m.group(2)), int(m.group(3))
        return [p + str(n) for n in range(a, b + 1)]
    m2 = re.match(r"^([A-Za-z]+\d+)\s*\(", tok)   # "R4-R12 (8x)" handled above
    return [tok] if tok else []

bom_refs = set()
fail = 0
for sec, lines in bomH.SECTIONS:
    for (ref, desc, mfr, pn, qty, unit, basis, note) in lines:
        toks = []
        for t in re.split(r"[,+]", ref or ""):
            t = re.sub(r"\s*\(.*\)$", "", t).strip()
            if t:
                toks += expand(t)
        for t in toks:
            if t not in net_refs:
                print("FAIL BOM refdes %r (line: %s) not in netlist" % (t, desc[:50]))
                fail += 1
            bom_refs.add(t)
        if not toks and qty and unit and not BULK_OK.search(desc) \
                and basis not in ("CATL", "KEHUA"):
            print("FAIL purchased line with NO refdes: %r" % desc[:70])
            fail += 1

missing = sorted(net_refs - bom_refs)
# jumper/crimp pseudo-refs live inside connector plugs, not BOM lines;
# X* field-interface points are drawing constructs (field wiring by others)
# unless the BOM itself claims them (X24/X25 purchased stations do appear)
missing = [r for r in missing
           if not re.match(r"^(JMP)\d", r) and not re.match(r"^X\d", r)]
for r in missing:
    print("FAIL netlist refdes %s missing from BOM" % r)
    fail += len(missing) and 1

print("netlist refs: %d   bom refs: %d   failures: %d"
      % (len(net_refs), len(bom_refs), fail))
if fail:
    print("RESULT: FAIL")
    sys.exit(1)
print("RESULT: PASS - BOM and netlist reconcile bidirectionally")
