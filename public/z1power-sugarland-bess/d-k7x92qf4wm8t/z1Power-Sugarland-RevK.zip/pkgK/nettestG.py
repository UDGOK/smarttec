"""Golden netlist diff: KiCad-extracted connectivity (from drawn wire
GEOMETRY) vs the independent design-intent table recorded at placement time.
Membership comparison, not name comparison, so auto-named local nets are
handled. Exit nonzero on any mismatch."""
import json
import sys
import xml.etree.ElementTree as ET

golden = {k: set(map(tuple, v)) for k, v in
          json.load(open("outG/golden_nets.json")).items()}

r = ET.parse("outG/netlist.xml").getroot()
comps = [c.get("ref") for c in r.find("components")]
knets = {}
for n in r.find("nets"):
    nodes = frozenset((nd.get("ref"), nd.get("pin")) for nd in n.findall("node"))
    knets[n.get("name")] = nodes

# index kicad nets by member
member_to_knet = {}
for name, nodes in knets.items():
    for m in nodes:
        member_to_knet[m] = name

fail = 0
matched_knets = set()
for gname, gmembers in sorted(golden.items()):
    anchor = next(iter(gmembers))
    kname = member_to_knet.get(anchor)
    if kname is None:
        print(f"FAIL {gname}: member {anchor} not in any KiCad net")
        fail += 1
        continue
    kmembers = set(knets[kname])
    if kmembers != gmembers:
        print(f"FAIL {gname} (kicad '{kname}'):")
        print(f"   missing from kicad: {sorted(gmembers - kmembers)}")
        print(f"   extra in kicad:     {sorted(kmembers - gmembers)}")
        fail += 1
    else:
        matched_knets.add(kname)
        # named global nets must keep their design name
        if not kname.startswith("/") and not kname.startswith("Net-") \
           and kname != gname:
            print(f"WARN name drift: golden {gname} -> kicad {kname}")

# any kicad net (>=2 nodes, not unconnected-*) not accounted for?
orphans = [k for k, v in knets.items()
           if len(v) >= 2 and not k.startswith("unconnected-")
           and k not in matched_knets]
singleton_spares = [k for k in knets if k.startswith("unconnected-")]

print()
print(f"components: {len(comps)}   kicad nets: {len(knets)}   golden nets: {len(golden)}")
print(f"matched: {len(matched_knets)}/{len(golden)}   failures: {fail}")
print(f"unmatched multi-node kicad nets: {orphans if orphans else 'none'}")
print(f"intentional spare-port no-connects: {len(singleton_spares)}")
if fail or orphans:
    print("RESULT: FAIL")
    sys.exit(1)
print("RESULT: PASS - drawn-wire geometry exactly reproduces design intent")
